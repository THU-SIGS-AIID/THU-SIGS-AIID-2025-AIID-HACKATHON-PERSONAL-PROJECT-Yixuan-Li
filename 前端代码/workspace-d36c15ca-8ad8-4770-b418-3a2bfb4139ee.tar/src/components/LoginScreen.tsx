"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface LoginScreenProps {
  onLogin: (username: string) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;

    setIsLoading(true);
    
    // Simulate login process
    setTimeout(() => {
      setIsLoading(false);
      onLogin(username.trim());
    }, 1000);
  };

  // iPhone 15 dimensions: 393 x 859
  const containerStyle = {
    width: '393px',
    height: '859px',
    maxWidth: '100vw',
    maxHeight: '100vh'
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-orange-100 to-pink-100 p-4">
      <div 
        className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-orange-300"
        style={containerStyle}
      >
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50 to-pink-50">
          <div className="absolute top-10 left-10 w-20 h-20 bg-orange-200 rounded-full opacity-30 blur-xl"></div>
          <div className="absolute bottom-20 right-10 w-32 h-32 bg-pink-200 rounded-full opacity-30 blur-xl"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-yellow-200 rounded-full opacity-20 blur-2xl"></div>
        </div>

        {/* Main content */}
        <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-8">
          {/* Logo and Title */}
          <div className="text-center mb-12">
            <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-pink-400 rounded-full flex items-center justify-center mb-6 shadow-xl border-4 border-white">
              <span className="text-4xl">🐼</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-800 mb-2">Ailurus Vocabulary</h1>
            <p className="text-lg text-gray-600">与小熊猫一起学习英语单词</p>
          </div>

          {/* Login Card */}
          <Card className="w-full max-w-sm border-2 border-orange-200 shadow-xl bg-white/90 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl font-bold text-orange-600">欢迎回来</CardTitle>
              <p className="text-sm text-gray-600">请输入您的信息开始学习</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                    用户名
                  </label>
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="请输入用户名"
                    className="w-full border-2 border-orange-200 rounded-lg px-4 py-3 focus:border-orange-400 focus:ring-orange-400"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                    密码
                  </label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="请输入密码（可选）"
                    className="w-full border-2 border-orange-200 rounded-lg px-4 py-3 focus:border-orange-400 focus:ring-orange-400"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || !username.trim()}
                  className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-bold py-3 rounded-lg shadow-lg transition-all transform hover:scale-105"
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      登录中...
                    </span>
                  ) : (
                    "开始学习"
                  )}
                </Button>
              </form>

              <div className="text-center text-sm text-gray-500 pt-4">
                <p>💡 提示：输入任意用户名即可开始</p>
              </div>
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="mt-8 text-center text-sm text-gray-500">
            <p>让学习英语变得有趣而简单</p>
          </div>
        </div>
      </div>
    </div>
  );
}