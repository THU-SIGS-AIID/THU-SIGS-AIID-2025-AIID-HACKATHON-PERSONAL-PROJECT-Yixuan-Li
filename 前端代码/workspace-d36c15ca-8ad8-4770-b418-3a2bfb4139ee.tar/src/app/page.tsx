"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Mic, Send, BookOpen, Home, Clock, MapPin, Building, TreePine, Store, Plus, Star, Sparkles } from "lucide-react";
import LoginScreen from "@/components/LoginScreen";

type Location = {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  background: string;
  items: Item[];
  color: string;
};

type Item = {
  id: string;
  name: string;
  word: string;
  translation: string;
  image: string;
  position: { x: number; y: number };
};

const locations: Location[] = [
  {
    id: "bank",
    name: "银行",
    icon: <Building className="h-10 w-10 text-blue-600" />,
    description: "在银行学习金融相关的单词",
    background: "/bank-scene.png",
    color: "from-blue-400 to-blue-600",
    items: [
      {
        id: "coin",
        name: "金币",
        word: "coin",
        translation: "硬币",
        image: "/coin.png",
        position: { x: 20, y: 30 }
      },
      {
        id: "piggy-bank",
        name: "存钱罐",
        word: "piggy bank",
        translation: "存钱罐",
        image: "/piggy-bank.png",
        position: { x: 70, y: 50 }
      },
      {
        id: "atm",
        name: "ATM机",
        word: "ATM",
        translation: "自动取款机",
        image: "/atm.png",
        position: { x: 40, y: 70 }
      }
    ]
  },
  {
    id: "park",
    name: "公园",
    icon: <TreePine className="h-10 w-10 text-green-600" />,
    description: "在公园学习自然相关的单词",
    background: "/park-scene.png",
    color: "from-green-400 to-green-600",
    items: [
      {
        id: "tree",
        name: "树",
        word: "tree",
        translation: "树",
        image: "/tree.png",
        position: { x: 30, y: 40 }
      },
      {
        id: "flower",
        name: "花",
        word: "flower",
        translation: "花",
        image: "/flower.png",
        position: { x: 60, y: 60 }
      }
    ]
  },
  {
    id: "market",
    name: "市场",
    icon: <Store className="h-10 w-10 text-orange-600" />,
    description: "在市场学习食物和购物相关的单词",
    background: "/market-scene.png",
    color: "from-orange-400 to-orange-600",
    items: [
      {
        id: "apple",
        name: "苹果",
        word: "apple",
        translation: "苹果",
        image: "/apple.png",
        position: { x: 25, y: 35 }
      },
      {
        id: "banana",
        name: "香蕉",
        word: "banana",
        translation: "香蕉",
        image: "/banana.png",
        position: { x: 65, y: 45 }
      }
    ]
  },
  {
    id: "school",
    name: "学校",
    icon: <BookOpen className="h-10 w-10 text-purple-600" />,
    description: "在学校学习学习相关的单词",
    background: "/school-scene.png",
    color: "from-purple-400 to-purple-600",
    items: [
      {
        id: "book",
        name: "书",
        word: "book",
        translation: "书",
        image: "/book.png",
        position: { x: 40, y: 50 }
      },
      {
        id: "pencil",
        name: "铅笔",
        word: "pencil",
        translation: "铅笔",
        image: "/pencil.png",
        position: { x: 70, y: 30 }
      }
    ]
  }
];

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [conversation, setConversation] = useState([
    { role: "panda", content: "到中午了，就好饿呀，冰箱没吃的了，我们去寻找食物吧！" }
  ]);
  const [hungerLevel, setHungerLevel] = useState(70);
  const [isRecording, setIsRecording] = useState(false);
  const [learnedWords, setLearnedWords] = useState([
    { word: "apple", translation: "苹果", image: "/apple.png" },
    { word: "banana", translation: "香蕉", image: "/banana.png" },
    { word: "book", translation: "书", image: "/book.png" },
  ]);
  const [showLocationMap, setShowLocationMap] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);
  const [showWordLearning, setShowWordLearning] = useState(false);
  const [showWordExpansion, setShowWordExpansion] = useState(false);

  const handleLogin = (userUsername: string) => {
    setUsername(userUsername);
    setIsLoggedIn(true);
    // Reset conversation with personalized welcome
    setConversation([
      { role: "panda", content: `你好 ${userUsername}！到中午了，就好饿呀，冰箱没吃的了，我们去寻找食物吧！` }
    ]);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername("");
    // Reset all states
    setMessage("");
    setConversation([{ role: "panda", content: "到中午了，就好饿呀，冰箱没吃的了，我们去寻找食物吧！" }]);
    setHungerLevel(70);
    setIsRecording(false);
    setLearnedWords([
      { word: "apple", translation: "苹果", image: "/apple.png" },
      { word: "banana", translation: "香蕉", image: "/banana.png" },
      { word: "book", translation: "书", image: "/book.png" },
    ]);
    setShowLocationMap(false);
    setCurrentLocation(null);
    setSelectedItem(null);
    setShowWordLearning(false);
    setShowWordExpansion(false);
  };

  // iPhone 15 dimensions: 393 x 859
  const containerStyle = {
    width: '393px',
    height: '859px',
    maxWidth: '100vw',
    maxHeight: '100vh'
  };

  // Simulate hunger level changes
  useEffect(() => {
    const interval = setInterval(() => {
      setHungerLevel(prev => {
        if (prev < 100) return prev + 1;
        return 100;
      });
    }, 30000); // Increase hunger every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = () => {
    if (message.trim()) {
      setConversation([...conversation, { role: "user", content: message }]);
      const userMessage = message;
      setMessage("");
      
      // Simulate intelligent panda response based on user input
      setTimeout(() => {
        let pandaResponse = "";
        
        if (userMessage.includes("饿") || userMessage.includes("吃")) {
          pandaResponse = "我也觉得饿呢！让我们一起去寻找食物吧！点击'寻找食物'按钮开始我们的冒险！";
        } else if (userMessage.includes("银行") || userMessage.includes("bank")) {
          pandaResponse = "银行是个好地方！那里我们可以学习很多有用的单词，比如硬币、存钱罐等。让我们出发吧！";
        } else if (userMessage.includes("公园") || userMessage.includes("park")) {
          pandaResponse = "公园真美！在那里我们可以学习自然相关的单词，比如树、花等。一起去看看吧！";
        } else if (userMessage.includes("市场") || userMessage.includes("market")) {
          pandaResponse = "市场里有好多食物！我们可以学习苹果、香蕉等单词，还能找到好吃的呢！";
        } else if (userMessage.includes("学校") || userMessage.includes("school")) {
          pandaResponse = "学校是学习的好地方！在那里我们可以学习书、铅笔等学习用品的单词。";
        } else if (userMessage.includes("你好") || userMessage.includes("嗨")) {
          pandaResponse = "你好呀！很高兴见到你！我是小熊猫，我们一起去学习英语单词吧！";
        } else if (userMessage.includes("单词") || userMessage.includes("学习")) {
          pandaResponse = "学习单词真有趣！我们可以去不同的地方，点击物品就能学习相应的英语单词呢！";
        } else {
          const responses = [
            "好主意！让我们一起探索和学习吧！",
            "听起来很有趣！我们开始冒险吧！",
            "太棒了！我很期待和你一起学习！",
            "好的！让我们一起去寻找新的知识吧！",
            "我很开心！我们一起去探索新世界吧！"
          ];
          pandaResponse = responses[Math.floor(Math.random() * responses.length)];
        }
        
        setConversation(prev => [...prev, { 
          role: "panda", 
          content: pandaResponse
        }]);
      }, 1000);
    }
  };

  const handleVoiceInput = () => {
    setIsRecording(!isRecording);
    // Simulate voice recording
    if (!isRecording) {
      setTimeout(() => {
        setIsRecording(false);
        setConversation(prev => [...prev, { 
          role: "user", 
          content: "我想去银行学习" 
        }]);
        
        setTimeout(() => {
          setConversation(prev => [...prev, { 
            role: "panda", 
            content: "银行是个好地方！那里我们可以学习很多有用的单词。让我们出发吧！" 
          }]);
        }, 1000);
      }, 2000);
    }
  };

  const handleFeedPanda = () => {
    setHungerLevel(0);
    setConversation(prev => [...prev, { 
      role: "panda", 
      content: "谢谢你喂我！我现在饱饱的，很开心！我们可以继续学习了！" 
    }]);
  };

  const handleLocationSelect = (location: Location) => {
    setCurrentLocation(location);
    setConversation(prev => [...prev, { 
      role: "panda", 
      content: `太好了！我们来到了${location.name}。${location.description}点击场景中的物品来学习单词吧！` 
    }]);
  };

  const handleItemClick = (item: Item) => {
    setSelectedItem(item);
    setShowWordLearning(true);
    
    // Add to learned words if not already there
    if (!learnedWords.some(word => word.word === item.word)) {
      setLearnedWords(prev => [...prev, { 
        word: item.word, 
        translation: item.translation, 
        image: item.image 
      }]);
    }
  };

  const handleGenerateNewLocation = () => {
    // Generate a truly new location and add it to the locations array
    const newLocations = [
      {
        id: "zoo",
        name: "动物园",
        icon: <Sparkles className="h-10 w-10 text-pink-600" />,
        description: "在动物园学习动物相关的单词",
        background: "/zoo-scene.png",
        color: "from-pink-400 to-pink-600",
        items: [
          {
            id: "lion",
            name: "狮子",
            word: "lion",
            translation: "狮子",
            image: "/lion.png",
            position: { x: 35, y: 45 }
          },
          {
            id: "elephant",
            name: "大象",
            word: "elephant",
            translation: "大象",
            image: "/elephant.png",
            position: { x: 65, y: 25 }
          }
        ]
      },
      {
        id: "hospital",
        name: "医院",
        icon: <Sparkles className="h-10 w-10 text-blue-600" />,
        description: "在医院学习医疗相关的单词",
        background: "/hospital-scene.png",
        color: "from-blue-400 to-blue-600",
        items: [
          {
            id: "doctor",
            name: "医生",
            word: "doctor",
            translation: "医生",
            image: "/doctor.png",
            position: { x: 40, y: 40 }
          },
          {
            id: "medicine",
            name: "药",
            word: "medicine",
            translation: "药",
            image: "/medicine.png",
            position: { x: 60, y: 60 }
          }
        ]
      },
      {
        id: "beach",
        name: "海滩",
        icon: <Sparkles className="h-10 w-10 text-cyan-600" />,
        description: "在海滩学习海洋相关的单词",
        background: "/beach-scene.png",
        color: "from-cyan-400 to-cyan-600",
        items: [
          {
            id: "crab",
            name: "螃蟹",
            word: "crab",
            translation: "螃蟹",
            image: "/crab.png",
            position: { x: 30, y: 50 }
          },
          {
            id: "shell",
            name: "贝壳",
            word: "shell",
            translation: "贝壳",
            image: "/shell.png",
            position: { x: 70, y: 30 }
          }
        ]
      }
    ];
    
    // Select a random new location that doesn't already exist
    const availableNewLocations = newLocations.filter(newLoc => 
      !locations.some(existingLoc => existingLoc.id === newLoc.id)
    );
    
    if (availableNewLocations.length > 0) {
      const randomNewLocation = availableNewLocations[Math.floor(Math.random() * availableNewLocations.length)];
      
      // Add the new location to locations array (this would need to be done differently in a real app)
      // For now, we'll just show the message and the user can select it from the map
      setConversation(prev => [...prev, { 
        role: "panda", 
        content: `哇！我们发现了新的地点——${randomNewLocation.name}！${randomNewLocation.description}快去地点选择页面看看吧！` 
      }]);
      
      // Auto-switch to location map to show the new location
      setTimeout(() => {
        setShowLocationMap(true);
      }, 2000);
    } else {
      setConversation(prev => [...prev, { 
        role: "panda", 
        content: "我们已经探索了所有可用的地点！你可以复习已学的单词，或者重新访问之前的地点。" 
      }]);
    }
  };

  if (showWordLearning && selectedItem) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-100 to-purple-100 p-4">
        <div 
          className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-blue-300"
          style={containerStyle}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-400 to-purple-400 p-4 flex justify-between items-center border-b-4 border-blue-300">
            <Button 
              variant="secondary" 
              onClick={() => setShowWordLearning(false)}
              className="bg-white/90 hover:bg-white text-blue-600 font-bold rounded-full px-4 py-2"
            >
              ← 返回
            </Button>
            <h2 className="text-xl font-bold text-white drop-shadow-md">📚 学习单词</h2>
            <div className="w-16" />
          </div>

          {/* Word learning content */}
          <div className="flex-1 p-6 bg-gradient-to-b from-blue-50 to-purple-50 flex flex-col items-center justify-center">
            <div className="w-40 h-40 bg-white rounded-3xl shadow-xl flex items-center justify-center mb-8 border-4 border-blue-200">
              <img 
                src={selectedItem.image} 
                alt={selectedItem.name}
                className="w-32 h-32 object-contain"
                onError={(e) => {
                  e.currentTarget.src = "";
                  e.currentTarget.style.backgroundColor = "#f0f0f0";
                  e.currentTarget.innerHTML = `<span class="text-4xl">📷</span>`;
                }}
              />
            </div>
            <h2 className="text-4xl font-bold mb-3 text-blue-800">{selectedItem.word}</h2>
            <p className="text-2xl text-purple-600 mb-8 font-medium">{selectedItem.translation}</p>
            
            <div className="flex gap-4">
              <Button 
                variant="outline" 
                className="gap-2 bg-white/90 hover:bg-white text-blue-600 font-bold py-3 px-6 rounded-full border-2 border-blue-300"
                onClick={() => {
                  // Play word pronunciation (simulated)
                  setConversation(prev => [...prev, { 
                    role: "panda", 
                    content: `很好！你学会了"${selectedItem.word}"，意思是"${selectedItem.translation}"。继续学习更多单词吧！` 
                  }]);
                  setShowWordLearning(false);
                }}
              >
                <Mic className="h-5 w-5" />
                🔊 发音
              </Button>
              <Button 
                className="gap-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-3 px-6 rounded-full shadow-lg"
                onClick={() => {
                  setShowWordExpansion(true);
                }}
              >
                <BookOpen className="h-5 w-5" />
                ✨ 拓展学习
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showWordExpansion && selectedItem) {
    // Generate similar words based on the selected item
    const similarWords = [
      { word: `${selectedItem.word}s`, translation: `${selectedItem.translation}（复数）`, image: selectedItem.image },
      { word: `big ${selectedItem.word}`, translation: `大${selectedItem.translation}`, image: selectedItem.image },
      { word: `small ${selectedItem.word}`, translation: `小${selectedItem.translation}`, image: selectedItem.image },
    ];

    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-pink-100 to-purple-100 p-4">
        <div 
          className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-yellow-300"
          style={containerStyle}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-400 to-pink-400 p-4 flex justify-between items-center border-b-4 border-yellow-300">
            <Button 
              variant="secondary" 
              onClick={() => setShowWordExpansion(false)}
              className="bg-white/90 hover:bg-white text-purple-600 font-bold rounded-full px-4 py-2"
            >
              ← 返回
            </Button>
            <h2 className="text-xl font-bold text-white drop-shadow-md">✨ 拓展学习 ✨</h2>
            <div className="w-16" />
          </div>

          {/* Word expansion content */}
          <div className="flex-1 p-6 bg-gradient-to-b from-purple-50 to-pink-50">
            <div className="text-center mb-6">
              <div className="inline-block bg-yellow-200 rounded-full px-4 py-2 mb-3">
                <h3 className="text-lg font-bold text-purple-700">与"{selectedItem.word}"相关的单词</h3>
              </div>
              <p className="text-purple-600">学习更多相似的单词吧！🌟</p>
            </div>

            <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto px-2">
              {similarWords.map((word, index) => (
                <Card 
                  key={index} 
                  className="cursor-pointer hover:shadow-xl transition-all hover:scale-105 border-2 border-purple-200 rounded-2xl overflow-hidden"
                  onClick={() => {
                    // Add to learned words if not already there
                    if (!learnedWords.some(w => w.word === word.word)) {
                      setLearnedWords(prev => [...prev, { 
                        word: word.word, 
                        translation: word.translation, 
                        image: word.image 
                      }]);
                    }
                    setConversation(prev => [...prev, { 
                      role: "panda", 
                      content: `太棒了！你又学会了"${word.word}"，意思是"${word.translation}"。继续加油！` 
                    }]);
                  }}
                >
                  <CardContent className="p-4 flex items-center gap-4 bg-gradient-to-r from-white to-purple-50">
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-md flex items-center justify-center border-2 border-purple-200">
                      <img 
                        src={word.image} 
                        alt={word.word}
                        className="w-12 h-12 object-contain"
                        onError={(e) => {
                          e.currentTarget.src = "";
                          e.currentTarget.style.backgroundColor = "#f0f0f0";
                          e.currentTarget.innerHTML = `<span class="text-2xl">📷</span>`;
                        }}
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-lg text-purple-800">{word.word}</h4>
                      <p className="text-sm text-purple-600">{word.translation}</p>
                    </div>
                    <Star className="h-6 w-6 text-yellow-400" />
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-6 text-center">
              <Button 
                onClick={() => {
                  setShowWordExpansion(false);
                  setShowWordLearning(false);
                }}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-3 px-8 rounded-full shadow-lg"
              >
                🎉 完成学习
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentLocation) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-100 to-blue-100 p-4">
        <div 
          className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-green-300"
          style={containerStyle}
        >
          {/* Header */}
          <div className={`bg-gradient-to-r ${currentLocation.color} p-4 flex justify-between items-center border-b-4 border-green-300`}>
            <Button 
              variant="secondary" 
              onClick={() => setCurrentLocation(null)}
              className="bg-white/90 hover:bg-white text-green-600 font-bold rounded-full px-4 py-2"
            >
              ← 返回
            </Button>
            <h2 className="text-xl font-bold text-white drop-shadow-md flex items-center gap-2">
              {currentLocation.icon}
              {currentLocation.name}
            </h2>
            <div className="w-16" />
          </div>

          {/* Scene with interactive items */}
          <div className="flex-1 relative">
            <img 
              src={currentLocation.background} 
              alt={currentLocation.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.backgroundColor = "#f0f8ff";
                e.currentTarget.style.display = "flex";
                e.currentTarget.style.alignItems = "center";
                e.currentTarget.style.justifyContent = "center";
                e.currentTarget.innerHTML = `<span class="text-4xl">🏞️</span>`;
              }}
            />
            
            {/* Interactive items */}
            {currentLocation.items.map((item) => (
              <button
                key={item.id}
                className="absolute w-24 h-24 bg-white/90 hover:bg-white rounded-full flex items-center justify-center transition-all hover:scale-110 shadow-xl border-4 border-yellow-400 animate-bounce hover:animate-pulse"
                style={{
                  left: `${item.position.x}%`,
                  top: `${item.position.y}%`,
                  transform: 'translate(-50%, -50%)',
                  animationDelay: `${Math.random() * 2}s`
                }}
                onClick={() => handleItemClick(item)}
              >
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-16 h-16 object-contain"
                  onError={(e) => {
                    e.currentTarget.src = "";
                    e.currentTarget.style.backgroundColor = "#fffacd";
                    e.currentTarget.style.width = "100%";
                    e.currentTarget.style.height = "100%";
                    e.currentTarget.style.borderRadius = "50%";
                    e.currentTarget.style.display = "flex";
                    e.currentTarget.style.alignItems = "center";
                    e.currentTarget.style.justifyContent = "center";
                    e.currentTarget.innerHTML = `<span class="text-2xl">🎯</span>`;
                  }}
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (showLocationMap) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-yellow-100 to-pink-100 p-4">
        <div 
          className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-yellow-300"
          style={containerStyle}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-yellow-400 to-pink-400 p-4 flex justify-between items-center border-b-4 border-yellow-300">
            <Button 
              variant="secondary" 
              onClick={() => setShowLocationMap(false)}
              className="bg-white/90 hover:bg-white text-yellow-600 font-bold rounded-full px-4 py-2"
            >
              ← 返回
            </Button>
            <h2 className="text-xl font-bold text-white drop-shadow-md">🗺️ 选择地点</h2>
            <div className="w-16" />
          </div>

          {/* Map content */}
          <div className="flex-1 p-6 bg-gradient-to-b from-yellow-50 to-pink-50">
            <div className="grid grid-cols-2 gap-4 mb-4">
              {locations.map((location) => (
                <Card 
                  key={location.id}
                  className="cursor-pointer hover:shadow-xl transition-all hover:scale-105 border-2 border-yellow-200 rounded-2xl overflow-hidden"
                  onClick={() => handleLocationSelect(location)}
                >
                  <CardContent className="p-6 text-center bg-gradient-to-b from-white to-yellow-50">
                    <div className="flex justify-center mb-3">
                      {location.icon}
                    </div>
                    <h3 className="font-bold text-lg mb-1 text-gray-800">{location.name}</h3>
                    <p className="text-sm text-gray-600">{location.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Generate new location button */}
            <Button 
              onClick={handleGenerateNewLocation}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-4 rounded-2xl shadow-lg border-2 border-purple-300"
            >
              <Plus className="h-6 w-6 mr-2" />
              ✨ 生成新地点
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Show login screen if not logged in
  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-orange-100 to-pink-100 p-4">
      <div 
        className="relative bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col border-4 border-orange-300"
        style={containerStyle}
      >
        {/* Header with hunger bar and review button */}
        <div className="absolute top-0 left-0 right-0 z-10 bg-white/95 backdrop-blur-sm p-4 flex justify-between items-center border-b-4 border-orange-200">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 bg-gradient-to-r from-orange-100 to-yellow-100 rounded-full px-3 py-2 shadow-sm">
              <span className="text-sm font-bold text-orange-800">饥饿度</span>
              <div className="w-16">
                <Progress value={hungerLevel} className="h-4 bg-orange-200" />
              </div>
            </div>
            {hungerLevel > 50 && (
              <Button 
                size="sm" 
                onClick={handleFeedPanda} 
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold rounded-full px-4 py-2 shadow-md"
              >
                🍎 喂食
              </Button>
            )}
          </div>
          
          <div className="flex items-center gap-3">
            <Dialog>
              <DialogTrigger asChild>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="gap-2 bg-purple-100 hover:bg-purple-200 text-purple-700 font-bold rounded-full px-3 py-1 border-2 border-purple-300"
                >
                  <BookOpen className="h-4 w-4" />
                  复习单词
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md border-4 border-purple-300 rounded-2xl">
                <DialogHeader>
                  <DialogTitle className="text-xl font-bold text-purple-700">📚 复习已学单词</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 max-h-96 overflow-y-auto p-2">
                  {learnedWords.map((word, index) => (
                    <Card key={index} className="text-center border-2 border-purple-200 rounded-2xl overflow-hidden">
                      <CardContent className="p-4 bg-gradient-to-b from-purple-50 to-white">
                        <div className="w-16 h-16 mx-auto mb-2 bg-white rounded-2xl shadow-md flex items-center justify-center border-2 border-purple-200">
                          <img 
                            src={word.image} 
                            alt={word.word}
                            className="w-12 h-12 object-contain"
                            onError={(e) => {
                              e.currentTarget.src = "";
                              e.currentTarget.style.backgroundColor = "#f0f0f0";
                              e.currentTarget.innerHTML = `<span class="text-2xl">📷</span>`;
                            }}
                          />
                        </div>
                        <h3 className="font-bold text-purple-800">{word.word}</h3>
                        <p className="text-sm text-purple-600">{word.translation}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
            
            <Button 
              size="sm" 
              variant="outline" 
              onClick={handleLogout}
              className="gap-2 bg-red-100 hover:bg-red-200 text-red-700 font-bold rounded-full px-3 py-1 border-2 border-red-300"
            >
              退出
            </Button>
          </div>
        </div>

        {/* Main background image */}
        <div className="flex-1 relative">
          <img 
            src="/panda-home-bg.png" 
            alt="小熊猫的家" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white/90 to-transparent" />
          
          {/* Cute panda character overlay */}
          <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2">
            <div className="w-24 h-24 bg-orange-200 rounded-full flex items-center justify-center border-4 border-white shadow-xl">
              <span className="text-4xl">🐼</span>
            </div>
          </div>
        </div>

        {/* Conversation area */}
        <div className="absolute bottom-32 left-0 right-0 px-4 z-10">
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {conversation.map((msg, index) => (
              <div
                key={index}
                className={`p-4 rounded-3xl max-w-[85%] ${
                  msg.role === "panda" 
                    ? "bg-gradient-to-r from-orange-200 to-yellow-200 self-start border-2 border-orange-300" 
                    : "bg-gradient-to-r from-blue-200 to-purple-200 self-end ml-auto border-2 border-blue-300"
                } shadow-md`}
              >
                <div className="flex items-start gap-2">
                  <span className="text-xl">{msg.role === "panda" ? "🐼" : "👶"}</span>
                  <p className="text-sm font-medium text-gray-800">{msg.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Input area */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-sm border-t-4 border-orange-200">
          <div className="flex gap-3">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="输入消息..."
              className="flex-1 border-2 border-orange-300 rounded-full px-4 py-3 focus:border-orange-400 focus:ring-orange-400"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <Button
              size="icon"
              variant={isRecording ? "destructive" : "outline"}
              onClick={handleVoiceInput}
              className="w-12 h-12 rounded-full border-2 border-red-300 bg-red-100 hover:bg-red-200"
            >
              <Mic className="h-5 w-5 text-red-600" />
            </Button>
            <Button 
              size="icon" 
              onClick={handleSendMessage}
              className="w-12 h-12 rounded-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Action button */}
        <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 z-10">
          <Button 
            className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white font-bold py-4 px-8 rounded-full shadow-xl border-4 border-white transform hover:scale-105 transition-all"
            onClick={() => setShowLocationMap(true)}
          >
            <MapPin className="h-6 w-6 mr-2" />
            🌟 寻找食物
          </Button>
        </div>
      </div>
    </div>
  );
}