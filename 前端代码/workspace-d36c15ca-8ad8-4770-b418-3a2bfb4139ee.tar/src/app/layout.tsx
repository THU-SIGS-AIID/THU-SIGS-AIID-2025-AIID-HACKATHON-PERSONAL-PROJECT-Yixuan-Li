import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "小熊猫英语学习 - 儿童英语学习APP",
  description: "以可爱小熊猫为主角的儿童英语学习软件，通过互动对话和场景探索帮助儿童学习英语单词",
  keywords: ["儿童英语学习", "小熊猫", "英语教育", "儿童APP", "单词学习"],
  authors: [{ name: "小熊猫英语学习团队" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "小熊猫英语学习",
    description: "以可爱小熊猫为主角的儿童英语学习软件",
    url: "https://chat.z.ai",
    siteName: "小熊猫英语学习",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "小熊猫英语学习",
    description: "以可爱小熊猫为主角的儿童英语学习软件",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
